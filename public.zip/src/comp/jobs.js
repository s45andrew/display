// src/components/About.js
import React from 'react';
import '../App.css';

const Jobs = () => {
  return (
     <div className='jobs'>
              <h1>vacancies</h1><br />
        </div>
  );
};

export default Jobs;
