// src/components/About.js
import React from 'react';
import '../App.css';

const Stock = () => {
  return  (
  <div className='stocks'>
            <h1>stock details Page</h1><br />
            </div>
  );
};

export default Stock;
