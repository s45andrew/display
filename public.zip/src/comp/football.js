// src/components/Home.js
import React from 'react';
import '../App.css';
const Football = () => {
  return (
  <div className='football'>
    <h1>footvall stuff Page</h1>
  </div>
  );
};

export default Football;
